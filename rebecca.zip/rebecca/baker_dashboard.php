<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "cake_ordering_system";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle ticket resolution
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve_ticket'])) {
    $ticket_id = intval($_POST['ticket_id']);
    $update = "UPDATE support_tickets SET status='resolved' WHERE id=$ticket_id";
    if ($conn->query($update)) {
        echo "<script>alert('Ticket marked as resolved.'); location.href=window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to update ticket.');</script>";
    }
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $conn->real_escape_string($_POST['new_status']);
    $updated_at = date("Y-m-d H:i:s");

    $updateOrder = "UPDATE orders SET status='$new_status', status_updated_at='$updated_at' WHERE order_id=$order_id";
    if ($conn->query($updateOrder)) {
        echo "<script>alert('Order status updated successfully.'); location.href=window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to update order status.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Baker Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #e91e63;
            margin-top: 40px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            vertical-align: top;
        }
        th {
            background-color: #f9f9f9;
        }
        .resolved {
            color: green;
            font-weight: bold;
        }
        button {
            padding: 6px 10px;
            background: #e91e63;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #d81b60;
        }
        select {
            padding: 5px;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<h1>🎂 Baker Dashboard</h1>

<!-- Orders Section -->
<h2>🧾 Cake Orders</h2>
<?php
$orderQuery = "SELECT * FROM orders ORDER BY created_at DESC";
$orderResult = $conn->query($orderQuery);
?>

<table>
    <tr>
        <th>Order ID</th>
        <th>Cake Name</th>
        <th>Customer</th>
        <th>Price</th>
        <th>Phone</th>
        <th>Payment Method</th>
        <th>Order Date</th>
        <th>Required Date</th>
        <th>Status</th>
        <th>Status Updated</th>
        <th>Update Status</th>
    </tr>
    <?php if ($orderResult && $orderResult->num_rows > 0): ?>
        <?php while ($order = $orderResult->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($order['order_id']) ?></td>
                <td><?= htmlspecialchars($order['cake_name']) ?></td>
                <td><?= htmlspecialchars($order['customer_name']) ?></td>
                <td><?= htmlspecialchars($order['price']) ?> TSh</td>
                <td><?= htmlspecialchars($order['phone']) ?></td>
                <td><?= htmlspecialchars($order['payment_method']) ?></td>
                <td><?= htmlspecialchars($order['created_at']) ?></td>
                <td><?= htmlspecialchars($order['required_date']) ?></td>
                <td><?= htmlspecialchars($order['status']) ?></td>
                <td><?= htmlspecialchars($order['status_updated_at']) ?></td>
                <td>
                    <form method="post">
                        <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                        <select name="new_status" required>
                            <option value="">--Select--</option>
                            <option value="Received" <?= $order['status'] == 'Received' ? 'selected' : '' ?>>Received</option>
                            <option value="Completed" <?= $order['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                        </select>
                        <button type="submit" name="update_status">Update</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="11">No orders found.</td></tr>
    <?php endif; ?>
</table>

<!-- Custom Cake Requests Section -->
<h2>🍰 Custom Cake Requests</h2>
<?php
$customQuery = "SELECT * FROM custom_requests ORDER BY created_at DESC";
$customResult = $conn->query($customQuery);
?>

<table>
    <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Flavor</th>
        <th>Instructions</th>
        <th>Date</th>
        <th>Delivery Type</th>
    </tr>
    <?php if ($customResult && $customResult->num_rows > 0): ?>
        <?php while ($row = $customResult->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['first_name']) ?></td>
                <td><?= htmlspecialchars($row['last_name']) ?></td>
                <td><?= htmlspecialchars($row['flavor']) ?></td>
                <td><?= nl2br(htmlspecialchars($row['instructions'])) ?></td>
                <td><?= htmlspecialchars($row['delivery_date']) ?></td>
                <td><?= htmlspecialchars($row['delivery_type']) ?></td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="7">No custom requests found.</td></tr>
    <?php endif; ?>
</table>

<!-- Support Tickets Section -->
<h2>🛠️ Support Tickets</h2>
<?php
$ticketsQuery = "SELECT * FROM support_tickets ORDER BY created_at DESC";
$ticketsResult = $conn->query($ticketsQuery);
?>

<table>
    <tr>
        <th>ID</th>
        <th>Customer Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
        <th>Status</th>
        <th>Created At</th>
        <th>Actions</th>
    </tr>
    <?php if ($ticketsResult && $ticketsResult->num_rows > 0): ?>
        <?php while ($ticket = $ticketsResult->fetch_assoc()): ?>
            <tr>
                <td><?= $ticket['id'] ?></td>
                <td><?= htmlspecialchars($ticket['customer_name']) ?></td>
                <td><?= htmlspecialchars($ticket['email']) ?></td>
                <td><?= htmlspecialchars($ticket['subject']) ?></td>
                <td><?= nl2br(htmlspecialchars($ticket['message'])) ?></td>
                <td><?= htmlspecialchars($ticket['status']) ?></td>
                <td><?= htmlspecialchars($ticket['created_at']) ?></td>
                <td>
                    <?php if ($ticket['status'] !== 'resolved'): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
                            <button type="submit" name="resolve_ticket">Mark Resolved</button>
                        </form>
                    <?php else: ?>
                        <span class="resolved">✅ Resolved</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="8">No support tickets found.</td></tr>
    <?php endif; ?>
</table>

</body>
</html>

<?php $conn->close(); ?>

<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "cake_ordering_system";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle image and form data upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cake_name = $_POST['cake_name'];
    $flavor = $_POST['flavor'];
    $price = $_POST['price'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $img_name = basename($_FILES['image']['name']);
        $target_dir = "uploads/";
        $target_path = $target_dir . time() . "_" . $img_name;

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            $stmt = $conn->prepare("INSERT INTO cake_gallery (cake_name, flavor, price, image_path) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssds", $cake_name, $flavor, $price, $target_path);

            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Cake uploaded successfully."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Database insert failed."]);
            }
            $stmt->close();
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to move uploaded file."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid image upload."]);
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Cake</title>
</head>
<body>
    <h2>Upload Cake Product</h2>
    <form action="upload_cake.php" method="post" enctype="multipart/form-data">
        Cake Name: <input type="text" name="cake_name" required><br><br>
        Flavor: <input type="text" name="flavor" required><br><br>
        Price (TSh): <input type="number" name="price" step="0.01" required><br><br>
        Image: <input type="file" name="image" accept="image/*" required><br><br>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
