<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cake Ordering Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="logo">🍰 Cake Haven</div>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Menu</a></li>
            <li><a href="#">Orders</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
    <section class="events">
        <h2>Upcoming Events</h2>
        <div class="event-list">
            <div class="event">
                <h3>Birthday Cake Special</h3>
                <p>Order a custom birthday cake and get 15% off!</p>
            </div>
            <div class="event">
                <h3>Wedding Cake Showcase</h3>
                <p>Explore our new wedding cake designs.</p>
            </div>
        </div>
    </section>
    <script src="script.js"></script>
</body>
</html>