<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Customer Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      margin: 0;
      padding: 20px;
    }
    h1, h2 {
      text-align: center;
    }
    .product-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      margin-bottom: 40px;
    }
    .product-card {
      background: white;
      border: 1px solid #ccc;
      border-radius: 8px;
      width: 250px;
      padding: 15px;
      text-align: center;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .product-card img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 5px;
    }
    .product-card button {
      margin-top: 10px;
      background: #4CAF50;
      color: white;
      border: none;
      padding: 10px;
      width: 100%;
      cursor: pointer;
    }
    .form-container {
      background: #fff;
      border: 1px solid #ccc;
      border-radius: 8px;
      max-width: 600px;
      margin: auto;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .form-container input, .form-container select, .form-container textarea {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      margin-bottom: 15px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }
    .form-container button {
      background: #2196F3;
      color: white;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
    }
    .nav {
      text-align: center;
      margin-top: 40px;
    }
    .nav a {
      margin: 0 10px;
      text-decoration: none;
      color: #2196F3;
      font-weight: bold;
    }
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0; top: 0;
      width: 100%; height: 100%;
      background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
      background: white;
      margin: 10% auto;
      padding: 20px;
      width: 90%;
      max-width: 500px;
      border-radius: 8px;
    }
    .close {
      float: right;
      font-size: 24px;
      cursor: pointer;
    }
  </style>
</head>
<body>

  <h1>Welcome to the Customer Dashboard</h1>

  <h2>🍰 Available Cakes</h2>
  <div class="product-container" id="productList">
    <?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "cake_ordering_system";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $galleryQuery = "SELECT * FROM cake_gallery ORDER BY uploaded_at DESC";
    $galleryResult = $conn->query($galleryQuery);

    if ($galleryResult && $galleryResult->num_rows > 0) {
      while ($cake = $galleryResult->fetch_assoc()) {
        $cakeJson = htmlspecialchars(json_encode([
          'name' => $cake['cake_name'],
          'flavor' => $cake['flavor'],
          'price' => $cake['price'],
          'image' => $cake['image_path']
        ]));
        echo "
          <div class='product-card'>
            <img src='{$cake['image_path']}' alt='{$cake['cake_name']}' />
            <h3>{$cake['cake_name']}</h3>
            <p><strong>Flavor:</strong> {$cake['flavor']}</p>
            <p><strong>Price:</strong> " . number_format($cake['price']) . " TSh</p>
            <button onclick='openModalWithProduct($cakeJson)'>Order</button>
          </div>
        ";
      }
    } else {
      echo "<p>No cakes available at the moment.</p>";
    }
    ?>
  </div>

<!-- Modal for order -->
<div id="orderModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <h3>Place Your Order</h3>
    <form id="orderForm" method="POST" action="">
      <input type="text" name="cake_name" placeholder="Cake Name" required>
      <input type="text" name="customer_name" placeholder="Customer Name" required>
      <input type="text" name="price" placeholder="Price (TSh)" required>
      <input type="text" name="phone" placeholder="Phone" required>

      <label>Select Payment Method:</label>
      <select name="payment_method" required>
        <option value="">Select</option>
        <option value="mpesa">M-Pesa</option>
        <option value="airtel">Airtel Money</option>
        <option value="tigo">Tigo Pesa</option>
        <option value="nmb">NMB Bank</option>
        <option value="crdb">CRDB Bank</option>
      </select>

      <label>Required Delivery Date:</label>
      <input type="date" name="required_date" required>

      <button type="submit" name="submit_order">Submit Order</button>
    </form>
  </div>
</div>

<h2>🎂 Custom Cake Request Form</h2>
<div class="form-container">
  <form id="customForm" method="POST" action="">
    <input type="text" name="c_first_name" placeholder="First Name" required>
    <input type="text" name="c_last_name" placeholder="Last Name" required>
    <input type="text" name="c_flavor" placeholder="Select Flavor" required>
    <textarea name="c_instructions" placeholder="Special Instructions" required></textarea>
    <input type="date" name="c_date" required>
    <select name="c_delivery" required>
      <option value="">Delivery Type</option>
      <option value="pickup">Pickup</option>
      <option value="delivery">Home Delivery</option>
    </select>
    <button type="submit" name="submit_custom">Send Request</button>
  </form>
</div>

<div class="nav">
  <a href="#">Customer Dashboard</a>
</div>

<script>
  const orderForm = document.getElementById('orderForm');

  function openModalWithProduct(product) {
    orderForm.cake_name.value = product.name;
    orderForm.price.value = product.price;
    document.getElementById('orderModal').style.display = 'block';
  }

  function closeModal() {
    document.getElementById('orderModal').style.display = 'none';
  }
</script>

<?php
// BACKEND - handle orders and custom requests

if (isset($_POST['submit_order'])) {
  $cake_name = $_POST['cake_name'];
  $customer_name = $_POST['customer_name'];
  $price = $_POST['price'];
  $phone = $_POST['phone'];
  $payment = $_POST['payment_method'];
  $required_date = $_POST['required_date'];

  $stmt = $conn->prepare("INSERT INTO orders (cake_name, customer_name, price, phone, payment_method, required_date) VALUES (?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("ssssss", $cake_name, $customer_name, $price, $phone, $payment, $required_date);

  if ($stmt->execute()) {
    $orderId = $conn->insert_id;
    echo "<script>
      alert('Order submitted successfully!\\nYour Order ID is: $orderId\\nPlease keep this ID to track your order.');
      window.location.href=window.location.href;
    </script>";
  } else {
    echo "<script>alert('Failed to submit order. Please try again.');</script>";
  }

  $stmt->close();
}

if (isset($_POST['submit_custom'])) {
  $cfname = $_POST['c_first_name'];
  $clname = $_POST['c_last_name'];
  $flavor = $_POST['c_flavor'];
  $instructions = $_POST['c_instructions'];
  $date = $_POST['c_date'];
  $delivery = $_POST['c_delivery'];

  $stmt = $conn->prepare("INSERT INTO custom_requests (first_name, last_name, flavor, instructions, delivery_date, delivery_type) VALUES (?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("ssssss", $cfname, $clname, $flavor, $instructions, $date, $delivery);
  $stmt->execute();
  echo "<script>alert('Custom cake request submitted!'); window.location.href=window.location.href;</script>";
  $stmt->close();
}

$conn->close();
?>
</body>
</html>
