<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; background-color: #f0f0f0; }
    h1, h2 { text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 40px; background-color: #fff; }
    table, th, td { border: 1px solid #ccc; }
    th, td { padding: 10px; text-align: left; }
    .form-inline { display: flex; flex-direction: column; }
    .form-inline textarea, .form-inline button { margin-top: 5px; }
    .form-inline button { width: 100px; padding: 5px; background: #2196F3; color: white; border: none; cursor: pointer; }
    .resolved { background-color: #d4edda; }
  </style>
</head>
<body>

<h1>Admin Dashboard</h1>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "cake_ordering_system";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!-- SUPPORT TICKETS -->
<h2>Support Tickets</h2>
<table>
  <tr>
    <th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Status</th><th>Actions</th>
  </tr>
  <?php
  $tickets = mysqli_query($conn, "SELECT * FROM support_tickets ORDER BY id DESC");
  while($row = mysqli_fetch_assoc($tickets)) {
    echo "<tr class='" . ($row['status'] == 'resolved' ? "resolved" : "") . "'>";
    echo "<td>{$row['id']}</td>";
    echo "<td>{$row['customer_name']}</td>";
    echo "<td>{$row['email']}</td>";
    echo "<td>{$row['subject']}</td>";
    echo "<td>{$row['message']}</td>";
    echo "<td>{$row['status']}</td>";
    echo "<td>
      <form class='form-inline' method='post' action='reply_ticket.php'>
        <input type='hidden' name='ticket_id' value='{$row['id']}'>
        <textarea name='reply' required placeholder='Write a reply'></textarea>
        <button type='submit'>Send</button>
      </form>
      <form method='post' action='resolve_ticket.php' style='margin-top:5px;'>
        <input type='hidden' name='ticket_id' value='{$row['id']}'>
        <button type='submit'>Resolve</button>
      </form>
    </td>";
    echo "</tr>";
  }
  ?>
</table>

<!-- CUSTOM CAKE REQUESTS -->
<h2>Custom Cake Requests</h2>
<table>
  <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Flavor</th><th>Instructions</th><th>Date</th><th>Delivery Type</th></tr>
  <?php
  $requests = mysqli_query($conn, "SELECT * FROM custom_requests ORDER BY id DESC");
  while($row = mysqli_fetch_assoc($requests)) {
    echo "<tr>
      <td>{$row['id']}</td>
      <td>{$row['first_name']}</td>
      <td>{$row['last_name']}</td>
      <td>{$row['flavor']}</td>
      <td>{$row['instructions']}</td>
      <td>{$row['delivery_date']}</td>
      <td>{$row['delivery_type']}</td>
    </tr>";
  }
  ?>
</table>

<!-- ADMINS -->
<h2>Admins</h2>
<table>
  <tr><th>ID</th><th>Username</th><th>Email</th></tr>
  <?php
  $admins = mysqli_query($conn, "SELECT * FROM admins");
  while($row = mysqli_fetch_assoc($admins)) {
    echo "<tr><td>{$row['id']}</td><td>{$row['username']}</td><td>{$row['email']}</td></tr>";
  }
  ?>
</table>

<!-- BAKERS -->
<h2>Bakers</h2>
<table>
  <tr><th>ID</th><th>Name</th><th>Email</th></tr>
  <?php
  $bakers = mysqli_query($conn, "SELECT * FROM bakers");
  while($row = mysqli_fetch_assoc($bakers)) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td></tr>";
  }
  ?>
</table>

<!-- CAKES -->
<h2>Cakes</h2>
<table>
  <tr><th>ID</th><th>Name</th><th>Flavor</th><th>Price</th></tr>
  <?php
  $cakes = mysqli_query($conn, "SELECT * FROM cakes");
  while($row = mysqli_fetch_assoc($cakes)) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['flavor']}</td><td>{$row['price']}</td></tr>";
  }
  ?>
</table>

<!-- CUSTOMERS -->
<h2>Customers</h2>
<table>
  <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th></tr>
  <?php
  $customers = mysqli_query($conn, "SELECT * FROM customers");
  while($row = mysqli_fetch_assoc($customers)) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td><td>{$row['phone']}</td></tr>";
  }
  ?>
</table>

<!-- ORDERS -->
<h2>Orders</h2>
<table>
  <tr><th>Order ID</th><th>Cake Name</th><th>Customer</th><th>Phone</th><th>Price</th><th>Status</th><th>Required Date</th></tr>
  <?php
  $orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY created_at DESC");
  while($row = mysqli_fetch_assoc($orders)) {
    echo "<tr><td>{$row['order_id']}</td><td>{$row['cake_name']}</td><td>{$row['customer_name']}</td>
    <td>{$row['phone']}</td><td>{$row['price']}</td><td>{$row['status']}</td><td>{$row['required_date']}</td></tr>";
  }
  ?>
</table>

<!-- INVENTORY -->
<h2>Inventory</h2>
<table>
  <tr><th>ID</th><th>Item</th><th>Quantity</th><th>Unit</th></tr>
  <?php
  $inv = mysqli_query($conn, "SELECT * FROM inventory");
  while($row = mysqli_fetch_assoc($inv)) {
    echo "<tr><td>{$row['id']}</td><td>{$row['item_name']}</td><td>{$row['quantity']}</td><td>{$row['unit']}</td></tr>";
  }
  ?>
</table>

<!-- DELIVERY PARTNERS -->
<h2>Delivery Partners</h2>
<table>
  <tr><th>ID</th><th>Name</th><th>Phone</th><th>Status</th></tr>
  <?php
  $partners = mysqli_query($conn, "SELECT * FROM delivery_partners");
  while($row = mysqli_fetch_assoc($partners)) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['phone']}</td><td>{$row['status']}</td></tr>";
  }
  ?>
</table>

</body>
</html>
