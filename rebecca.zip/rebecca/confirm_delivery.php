<?php
$conn = new mysqli("localhost", "root", "", "cake_ordering_system");

$order_id = $_POST['order_id'];
$status = $_POST['status'];

$stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
$stmt->bind_param("si", $status, $order_id);
$stmt->execute();

header("Location: track-order.php = $order_id");
exit();
?>
